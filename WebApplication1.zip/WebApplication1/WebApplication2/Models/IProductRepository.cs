﻿namespace WebApplication2.Models
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetAll();
        Product Get(int id);
        Product AddProduct(Product item);
        bool Update(Product item);
        void Remove(int id);
    }
}