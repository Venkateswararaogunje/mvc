﻿namespace WebApplication1
{
    public class WelcomeMessage
    {
        public string Message { get; }
        public WelcomeMessage(string message)
        {
            Message = message;
        }
    }
}
